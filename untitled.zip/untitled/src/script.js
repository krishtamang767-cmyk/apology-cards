document.addEventListener("DOMContentLoaded", function () {

  /* FORGIVENESS METER */

  const meter = document.getElementById("meter");
  const percentage = document.getElementById("percentage");
  const meterMessage = document.getElementById("meterMessage");

  if (meter) {
    function updateMeter() {
      const value = meter.value;

      percentage.textContent = value + "%";
      meter.style.setProperty("--progress", value + "%");

      if (value < 25) {
        meterMessage.textContent =
          "Okay... I know I have work to do 🥺";
      } else if (value < 50) {
        meterMessage.textContent =
          "I'm trying my best here... 🥹";
      } else if (value < 75) {
        meterMessage.textContent =
          "We're getting somewhere... 🥺💕";
      } else if (value < 100) {
        meterMessage.textContent =
          "I think I can see a little smile... 👀❤️";
      } else {
        meterMessage.textContent =
          "YAY! I'll try my best to do better ❤️";
      }
    }

    meter.addEventListener("input", updateMeter);
    updateMeter();
  }


  /* LITTLE SURPRISE */

  const surpriseButton =
    document.getElementById("surpriseButton");

  const surpriseMessage =
    document.getElementById("surpriseMessage");

  if (surpriseButton && surpriseMessage) {

    surpriseButton.addEventListener("click", function () {

      surpriseMessage.classList.toggle("show");

      if (surpriseMessage.classList.contains("show")) {
        surpriseButton.textContent =
          "💗 Hide my little secret";
      } else {
        surpriseButton.textContent =
          "💌 Tap for a little surprise";
      }

    });

  }


  /* REASONS */

  const reasonButton =
    document.getElementById("reasonButton");

  const reasonBox =
    document.getElementById("reasonBox");

  const reasons = [
    "Your smile can genuinely make my day. ❤️",
    "You can make ordinary moments feel special. 🌷",
    "You have a way of staying on my mind. 🥹",
    "Some of my favourite memories have you in them. 💗",
    "You are simply... you. And that's pretty special. ✨",
    "There are honestly too many things to fit on this page. ♡"
  ];

  let reasonIndex = 0;

  if (reasonButton && reasonBox) {

    reasonButton.addEventListener("click", function () {

      reasonBox.style.opacity = "0";

      setTimeout(function () {

        reasonBox.textContent =
          reasons[reasonIndex];

        reasonIndex++;

        if (reasonIndex >= reasons.length) {
          reasonIndex = 0;
        }

        reasonBox.style.opacity = "1";

      }, 150);

    });

  }


  /* HEART BUTTON */

  const heartButton =
    document.getElementById("heartButton");

  const tapCount =
    document.getElementById("tapCount");

  let count = 0;

  if (heartButton && tapCount) {

    heartButton.addEventListener("click", function (event) {

      count++;
      tapCount.textContent = count;

      heartButton.style.transform = "scale(0.85)";

      setTimeout(function () {
        heartButton.style.transform = "";
      }, 120);


      for (let i = 0; i < 4; i++) {

        const heart =
          document.createElement("div");

        heart.className = "pop-heart";
        heart.textContent = "♥";

        heart.style.left =
          (event.clientX + Math.random() * 60 - 30) + "px";

        heart.style.top =
          (event.clientY + Math.random() * 30 - 15) + "px";

        document.body.appendChild(heart);

        setTimeout(function () {
          heart.remove();
        }, 1000);

      }

    });

  }


  /* FINAL SURPRISE */

  const finalButton =
    document.getElementById("finalButton");

  const finalSurprise =
    document.getElementById("finalSurprise");

  if (finalButton && finalSurprise) {

    finalButton.addEventListener("click", function () {

      finalSurprise.classList.toggle("show");

      if (finalSurprise.classList.contains("show")) {

        finalButton.textContent =
          "You found the last little thing ❤️";

        for (let i = 0; i < 15; i++) {

          setTimeout(function () {

            const heart =
              document.createElement("div");

            heart.className = "pop-heart";
            heart.textContent = "♥";

            heart.style.left =
              Math.random() * window.innerWidth + "px";

            heart.style.top =
              window.innerHeight + "px";

            document.body.appendChild(heart);

            setTimeout(function () {
              heart.remove();
            }, 1000);

          }, i * 80);

        }

      } else {

        finalButton.textContent =
          "One last little thing ✨";

      }

    });

  }

});